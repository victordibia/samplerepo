# Ensures the repo root is on sys.path so `import app` works under pytest.
