# Notes Feed

A small notes-feed application.

## Run it

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

./run.sh
```

Then open http://localhost:8000

## Tests

```bash
source .venv/bin/activate
pytest -q
```
