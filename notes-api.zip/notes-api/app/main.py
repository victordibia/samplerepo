import asyncio
import datetime
import os
import random
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Query
from fastapi.staticfiles import StaticFiles

from app import seed as seed_module
from app.db import get_conn, init_db

LIVE_FEED = os.environ.get("NOTES_LIVE_FEED", "0") == "1"
STATIC_DIR = str(Path(__file__).resolve().parent.parent / "static")


def insert_note(author: str, text: str):
    conn = get_conn()
    conn.execute(
        "INSERT INTO notes (author, text, created_at) VALUES (?, ?, ?)",
        (author, text, datetime.datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()


async def live_feed_writer():
    """Simulate other customers posting to the feed while a user scrolls."""
    i = 0
    while True:
        await asyncio.sleep(2.0)
        i += 1
        author = random.choice(seed_module.AUTHORS)
        insert_note(author, f"{author} posted a live update (#{i})")


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    task = asyncio.create_task(live_feed_writer()) if LIVE_FEED else None
    yield
    if task:
        task.cancel()


app = FastAPI(title="Notes Feed", lifespan=lifespan)


@app.get("/notes")
def list_notes(
    limit: int = Query(10, ge=1, le=100),
    offset: int = Query(0, ge=0),
):
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, author, text, created_at FROM notes "
        "ORDER BY created_at DESC, id DESC "
        "LIMIT ? OFFSET ?",
        (limit, offset),
    ).fetchall()
    total = conn.execute("SELECT COUNT(*) AS c FROM notes").fetchone()["c"]
    conn.close()
    return {
        "notes": [dict(r) for r in rows],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


# Static feed UI (served at /). Defined after API routes so /notes wins.
app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")
