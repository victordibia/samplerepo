import datetime
import random

from app.db import get_conn, init_db

AUTHORS = ["alice", "bob", "carol", "dave", "erin", "frank", "grace", "heidi"]

SNIPPETS = [
    "shipped the new onboarding flow",
    "reviewing the Q3 roadmap",
    "coffee machine is broken again",
    "great sync with the design team",
    "deploy went out clean",
    "anyone seen the staging logs?",
    "pairing on the caching bug",
    "lunch at the new place downtown",
    "wrote up the incident postmortem",
    "demo landed well with the customer",
    "flaky test is finally green",
    "reading about keyset pagination",
]


def seed(n: int = 60):
    """Seed the feed with n notes, oldest first so ids increase with time."""
    init_db()
    conn = get_conn()
    conn.execute("DELETE FROM notes")
    now = datetime.datetime.utcnow()
    for i in range(n):
        # oldest note first; newest note is created most recently
        created = now - datetime.timedelta(minutes=(n - i))
        author = random.choice(AUTHORS)
        text = f"{author} {random.choice(SNIPPETS)} (message {i + 1})"
        conn.execute(
            "INSERT INTO notes (author, text, created_at) VALUES (?, ?, ?)",
            (author, text, created.isoformat()),
        )
    conn.commit()
    conn.close()


if __name__ == "__main__":
    seed()
    print("Seeded notes.db")
