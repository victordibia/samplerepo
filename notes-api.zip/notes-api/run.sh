#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
pip install -q -r requirements.txt

python -m app.seed
NOTES_LIVE_FEED=1 uvicorn app.main:app --port 8000
