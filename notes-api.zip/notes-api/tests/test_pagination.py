import os
import tempfile

# Use an isolated DB and no live feed for tests.
os.environ["NOTES_DB"] = os.path.join(tempfile.mkdtemp(), "test_notes.db")
os.environ["NOTES_LIVE_FEED"] = "0"

from fastapi.testclient import TestClient  # noqa: E402

from app import seed  # noqa: E402
from app.main import app  # noqa: E402


def _all_ids_by_paging(client, total, limit=10):
    ids = []
    for offset in range(0, total, limit):
        r = client.get(f"/notes?limit={limit}&offset={offset}")
        assert r.status_code == 200
        ids += [n["id"] for n in r.json()["notes"]]
    return ids


def test_pagination_returns_every_note_once():
    seed.seed(30)
    client = TestClient(app)
    ids = _all_ids_by_paging(client, total=30, limit=10)
    assert len(ids) == 30
    assert len(set(ids)) == 30  # no duplicates


def test_pagination_is_ordered_newest_first():
    seed.seed(30)
    client = TestClient(app)
    r = client.get("/notes?limit=30&offset=0")
    ids = [n["id"] for n in r.json()["notes"]]
    assert ids == sorted(ids, reverse=True)


def test_notes_have_expected_shape():
    seed.seed(5)
    client = TestClient(app)
    note = client.get("/notes?limit=1&offset=0").json()["notes"][0]
    assert set(note.keys()) == {"id", "author", "text", "created_at"}
