// Simple infinite-scroll feed client.
// Fetches pages of notes and appends them as they load.

const LIMIT = 8;
let offset = 0;
let loading = false;

const renderedIds = new Set();
let rendered = 0;

const feedEl = document.getElementById("feed");
const statsEl = document.getElementById("stats");
const loadMoreBtn = document.getElementById("loadMore");

function updateStats(total) {
  statsEl.innerHTML =
    `feed size: <b>${total}</b> &nbsp;•&nbsp; ` +
    `cards shown: <b>${rendered}</b>`;
}

function renderNote(note) {
  const isRepeated = renderedIds.has(note.id);
  renderedIds.add(note.id);
  rendered += 1;

  const card = document.createElement("article");
  card.className = "note" + (isRepeated ? " repeated" : "");

  const when = new Date(note.created_at + "Z").toLocaleTimeString();
  card.innerHTML =
    `<div class="meta">
       <span class="author">@${note.author}</span>
       <span class="id">#${note.id}</span>
       <span class="time">${when}</span>
     </div>
     <div class="text">${note.text}</div>`;
  feedEl.appendChild(card);
}

async function loadMore() {
  if (loading) return;
  loading = true;
  loadMoreBtn.disabled = true;
  try {
    const res = await fetch(`/notes?limit=${LIMIT}&offset=${offset}`);
    const data = await res.json();
    data.notes.forEach(renderNote);
    offset += data.notes.length;
    updateStats(data.total);
  } finally {
    loading = false;
    loadMoreBtn.disabled = false;
  }
}

loadMoreBtn.addEventListener("click", loadMore);

window.addEventListener("scroll", () => {
  const nearBottom =
    window.innerHeight + window.scrollY >= document.body.offsetHeight - 300;
  if (nearBottom) loadMore();
});

// Load the first couple of pages so there is something to scroll.
loadMore().then(loadMore);
